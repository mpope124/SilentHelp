const mongoose = require('mongoose');

const IncidentSchema = new mongoose.Schema({
title: String,
  keywordsDetected: [String],
  timestamp: String,
  severity: String,
  contact: [String],    
  location: String,        
  audioPath: String
});

module.exports = mongoose.model('Incident', IncidentSchema);