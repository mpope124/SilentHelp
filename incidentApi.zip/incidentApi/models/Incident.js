const mongoose = require('mongoose');

const IncidentSchema = new mongoose.Schema({
  title: String,
  description: String,
  date: { type: Date, default: Date.now },
  location: String,
  severity: String
});

module.exports = mongoose.model('Incident', IncidentSchema);