const express = require('express');
const router = express.Router();
const Incident = require('../models/Incident');

// Create
router.post('/', async (req, res) => {
  try {
    const incident = new Incident(req.body);
    await incident.save();
    res.status(201).json(incident);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Read all
router.get('/', async (req, res) => {
  const incidents = await Incident.find();
  res.json(incidents);
});

// Read by ID
router.get('/:id', async (req, res) => {
  try {
    const incident = await Incident.findById(req.params.id);
    if (!incident) return res.status(404).send('Not found');
    res.json(incident);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Update
router.put('/:id', async (req, res) => {
  try {
    const incident = await Incident.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(incident);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Delete
router.delete('/:id', async (req, res) => {
  try {
    await Incident.findByIdAndDelete(req.params.id);
    res.send('Incident deleted');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

module.exports = router;
